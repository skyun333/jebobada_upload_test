CLIENT_ID = "d83fc9e4ac2b4792ba4bb6c6215d8696"
REDIRECT_URI = "http://127.0.0.1:5000/oauth"
KAKAO_AUTH_URL  = 'https://kauth.kakao.com/oauth/'
 