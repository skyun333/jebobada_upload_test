from weakref import ProxyTypes
from flask import Flask, render_template,request, redirect, jsonify
import pymongo
import requests

app = Flask("__main__")

#전역선언X 요청이 올때마다 새로 선언
#커넥션을 계속해서 refresh 해주는 방식으로 변경
conn =pymongo.MongoClient('127.0.0.1',27017)
db = conn.jb_db
collection = db.user
db = conn.get_database('jb_db')
collection = db.get_collection('user')

@app.route("/")
def my_index():
    return render_template("index.html",tocken="Hello Flask+React")

@app.route("/signup",methods=['GET','POST'])
def signup(): 
    if request.method == 'GET':
        return render_template("index.html")
    else:
        data=request.get_json()
        username = data['user_name']
        userid = data['user_id']
        password = data['user_pwd']
        # re_password = data['user_pwd2']

        print(data)

        userinfo={'user_id':userid, 'user_name':username, 'user_pwd':password}
        
        # if not (userid and username and password and re_password):    
        if not (userid and username and password):
            return jsonify({'result':'input_all'})
        # elif password != re_password:
        #     return jsonify({'result':'check_pwd'})
        else:
            db.user.insert_one(userinfo)
            print("aaa")
            return jsonify({'result':'success','msg':'register'})
        

@app.route("/signup/check",methods=['GET'])
def check_id():
    userid = request.form.get('userid')
    checking = db.user.find_one({'userid':userid})
    if checking is not None:
        return jsonify({'result':'fail','msg':'already existed'})

@app.route("/oauth")
def oauth():
    # code = request.args.get('code')
    url = "https://kauth.kakao.com/oauth/token"
    param = request.get_json()
    client_id = param['client_id']
    redirect_uri = param['redirect_uri']
    code = param['code']

    requests.post(
        url = url,
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Cache-Control": "no-cache",
        },
        data = {
            "grant_type": "authorization_code",
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "code": code,
        }
    ).json()

    return render_template("index.html")

app.run(debug=True)