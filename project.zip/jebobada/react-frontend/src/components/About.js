import React from 'react';
import Header from './Header';

const About = () => {
    return(
        <div>
            <Header/>
            <h1>제로보드 소개 페이지</h1>
        </div>
    )
}

export default About;