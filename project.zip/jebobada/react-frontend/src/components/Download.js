import React from 'react';
import Header from './Header';


const Download = () => {
    return(
        <div>
            <Header/>
            <h1>다운로드 페이지</h1>
        </div>
    )
}

export default Download;