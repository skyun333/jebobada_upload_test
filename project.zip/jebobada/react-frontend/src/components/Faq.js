import React from 'react';
import Header from './Header';


const Faq = () => {
    return(
        <div>
            <Header/>
            <h1>질문게시판</h1>
        </div>
    )
}

export default Faq;