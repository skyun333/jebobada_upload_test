import React from 'react';
import Header from './Header';


const Upload = () => {
    return(
        <div>
            <Header/>
            <h1>증거 업로드 페이지</h1>
        </div>
    )
}

export default Upload;