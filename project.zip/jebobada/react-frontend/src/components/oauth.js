import React from 'react';
import Header from './Header';
import axios from 'axios';
import {useDispatch} from "react-redux"
import { CLIENT_ID, REDIRECT_URI} from './config';

// import {actionCreators as userActions} from "./user"


const Oauth = () => {
    let code = new URL(window.location.href).searchParams.get("code");
    console.log(code)
    
    axios.post("/oauth",{
        client_id: CLIENT_ID,
        redirect_uri: REDIRECT_URI,
        code: code
    })
    .then(res=>{
        console.log(res)
    })

    React.useEffect(async()=>{
        await dispatch(userActions.kakaoLogin(code))
    },[]);

    return(
        <div>
            <Header/>
        </div>
    )
}

export default Oauth;